﻿using UnityEngine;
using MySql.Data.MySqlClient;

public class Database : MonoBehaviour
{
    MySqlConnection connection;

    // Use this for initialization 
    void Start()
    {
        SetupSQLConnection();
        TestDB();
        CloseSQLConnection();
    }
    
    //begins connection
    private void SetupSQLConnection()
    {
        if (connection == null)
        {
            string connectionString = "SERVER=127.0.0.1;" + "DATABASE=unity;" + "UID=player;" + "PASSWORD=12345;";
            try
            {
                connection = new MySqlConnection(connectionString);
                connection.Open();
            }
            catch (MySqlException ex)
            {
                Debug.LogError("MySQL Error: " + ex.ToString());
            }
        }
    }
    

    //closes connection
    private void CloseSQLConnection()
    {
        if (connection != null)
        {
            connection.Close();
        }
    }


    public void TestDB()
    {
        string commandText = string.Format("INSERT INTO scores (playername, playerscore) VALUES ({0}, {1})", "'megaplayer'", 10);
        if (connection != null)
        {
            MySqlCommand command = connection.CreateCommand();
            command.CommandText = commandText;
            try
            {
                command.ExecuteNonQuery();
            }
            catch (System.Exception ex)
            {
                Debug.LogError("MySQL error: " + ex.ToString());
            }
        }
    }
}